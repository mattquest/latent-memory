# Matched-trace context pressure

Status: **complete**.

All source questions are retained. The secondary overflow subset is defined by cumulative source-token exposure, not correctness.

| Arm | Subset | n | EM | F1 | Replay p50 / p95 (s) | Mean source planning / search (s) |
| --- | --- | --- | --- | --- | --- | --- |
| retained_kv_bf16 | all | 6 | 0.0% | 0.0% | 1.41 / 1.92 | 1.75 / 0.01 |
| retained_kv_bf16 | trace_overflow | 1 | 0.0% | 0.0% | 1.94 / 1.94 | 2.80 / 0.01 |
| retained_kv_int8 | all | 6 | 0.0% | 0.0% | 1.45 / 1.96 | 1.75 / 0.01 |
| retained_kv_int8 | trace_overflow | 1 | 0.0% | 0.0% | 1.98 / 1.98 | 2.80 / 0.01 |
| retained_text | all | 6 | 0.0% | 0.0% | 0.56 / 0.77 | 1.75 / 0.01 |
| retained_text | trace_overflow | 1 | 0.0% | 0.0% | 0.72 / 0.72 | 2.80 / 0.01 |
| rolling_summary | all | 6 | 0.0% | 0.0% | 0.62 / 4.89 | 1.75 / 0.01 |
| rolling_summary | trace_overflow | 1 | 0.0% | 0.0% | 5.41 / 5.41 | 2.80 / 0.01 |

## Original references

These timings include original search and planning; replay timings above exclude those separately listed costs.

| Original arm | Subset | n | EM | Original end-to-end p50 / p95 (s) |
| --- | --- | --- | --- | --- |
| basic_rag | all | 6 | 0.0% | 0.39 / 0.62 |
| basic_rag | trace_overflow | 1 | 0.0% | 0.45 / 0.45 |
| iterative_text | all | 6 | 0.0% | 1.99 / 3.69 |
| iterative_text | trace_overflow | 1 | 0.0% | 3.81 / 3.81 |

## Limits

- Shared-trace retention/interference ablation; controller decisions were made in the original larger-context run.
- All questions are included; overflow is defined by source-token exposure, not answer correctness.
- Evidence budget counts source tokens, KV slots and summary wrappers. Fixed prompts/questions and output reservations are additional, explicitly logged.
- Int8 reduces stored bytes, not attention positions. No trained latent compressor or latent query controller is tested.
- Most questions may have sufficient support within the smaller window. Overflow does not prove necessary information exceeds context.
- Support-ID coverage is annotation provenance, not proof truncated text or generated notes preserve the facts.
- Basic RAG and larger-context adaptive references retain their original retrieval settings and measured end-to-end costs.
