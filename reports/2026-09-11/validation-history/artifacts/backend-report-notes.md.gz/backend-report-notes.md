# Backend and methods facts for the final README

Verified against the implemented code, `docs/guiding-plan.txt`, the local official model configuration, and `runs/native-validation-relative/process.log`. This file contains methods and validation facts, not the final benchmark results. No model inference was run while preparing it.

## Suggested short implementation paragraph

The repository now runs real Qwen3-8B inference on MLX and evaluates document KV-cache relay against decoded text notes and direct text context. It implements independent document prefill, RoPE position correction, causal cache continuation, selective boundary recomputation, and packed 8-bit/4-bit cache storage. All conditions share one unadapted BF16 checkpoint. The experiments use fixed evidence schedules; they do not implement the proposed trained planner, verifier, latent retrieval projection, or complete memory MCP server.

## Model and actual relay mechanism

- **Checkpoint:** official `Qwen/Qwen3-8B`, revision `b968826d9c46dd6066d109eabc6255188de91218`; BF16 weights throughout. The download manifest totals 16,397,431,693 bytes, including tokenizer/configuration files. Runtime versions recorded in numerical validation: MLX 0.32.2, mlx-lm 0.31.3, Transformers 5.17.0, NumPy 2.5.3.
- **Architecture:** 36 full-attention layers, 32 query heads, eight KV heads, head dimension 128. Standard unscaled RoPE has base 1,000,000. The implementation explicitly rejects other model types, scaled RoPE, and quantized-weight configurations; it has not validated hybrid, sliding-window, or cross-model relay.
- **Prefill:** each document is causally prefilled independently, so its tokens attend to preceding tokens within that document. Different documents do not initially attend to one another. Native snapshots contain per-layer MLX arrays shaped `[1, KV heads, tokens, head dimension]`, plus original token IDs and block boundaries. Retained token IDs enable recomputation without decoding an intermediate message.
- **Positions:** saved keys are already RoPE-rotated. When a block moves from local position `t` to `t + Δ`, concat applies the constant rotation `R(Δ)` to every key; values are unchanged. A singleton sequence per key prevents adding the within-block position twice. The rotation is computed in float32 and stored back in BF16. Subsequent stock Qwen3 causal attention uses the concatenated cache as a prefix visible to all new tokens.
- **Bridge:** the selector chooses `ceil(ratio × total_tokens)` positions nearest existing block boundaries when boundaries exist, then recomputes contiguous selected spans against the full preceding causal cache. Unselected tokens retain their previous states. With ratio 1, all original tokens are jointly prefilled from scratch. The fractions refer to selected tokens across the assembled sequence, not a percentage of a separately defined boundary-token subset. Rounding and sequence length can make the actual fraction differ from the requested fraction.
- **Important bridge distinction:** this is a boundary-distance heuristic, not CacheBlend/CacheClip's published selection algorithm. It uses causal preceding context, not bidirectional attention to later tokens. Recompute at one hop can include states retained from previous hops. A recomputation fraction is not an equal fraction of wall time: copies, attention over preceding context, and materialization also cost time.
- **Precision:** affine group quantization packs the cache into uint32 arrays at 8 or 4 bits per element, with BF16 scale and bias per group of 64 dimensions. Caches dequantize to BF16 for concatenation, position correction, recomputation, and attention. This is storage/relay quantization; model weights and attention computation stay BF16. E1/E2/E6 quantize after each active latent hop, whereas E5 quantizes the assembled relay once before synthesis.
- **Decoding and bounds:** deterministic greedy decoding with Qwen3's non-thinking assistant prefix; final decoding stops at EOS or the configured cap. Prompt forwards run in batches of 256 tokens and materialize each batch. The backend caps total requested context at 8,192 tokens and MLX allocations at 32 GiB. It uses direct model forwards, not `mlx_lm.generate`, and does not raise wired-memory limits. Passing an object reference is cheap; constructing and consuming a relay is not free.
- **No trained roles:** adapter names other than `base` fail explicitly. A latent hop appends a short question-specific retention instruction and runs a real causal forward. There is no learned support score, adaptive stop decision, projected retrieval query, continuous latent-thought rollout, or separate planner/reader/verifier model.

## What E1–E6 actually test

| Experiment | Implemented comparison | Limit relative to the guiding design |
| --- | --- | --- |
| E1 — equal hops | Same evidence schedule, hop budget, checkpoint, and final output cap. Text hops decode compact JSON evidence notes; latent hops merge document caches and append a retention prompt; direct text presents the selected documents together. BF16 and int8 latent variants are separate. | Equal evidence does not make these trained, role-equivalent agents. Text notes can discard evidence; latent caches retain source-token states. The direct-text arm is an essential recomputation baseline. A loss greater than two points alone does not prove broken mechanics. |
| E2 — hop sweep | Nominal budgets 1, 3, 5, 10, 20 increase available evidence under a recorded fixed ranking. Empty/exhausted hops are skipped and the actual executed evidence-hop count is recorded. | Tests evidence-budget and representation tradeoffs, not adaptive latent retrieval or trained verification. Flat curves after evidence exhaustion do not kill the original adaptive-search thesis; rising curves do not isolate latent reasoning from receiving more evidence. |
| E3 — private-cache audit | Single-document synthetic private facts; correct, mismatched, zero, moment-matched random, and no-context controls. The receiver keeps its question and framing; the evidence cache is intervened on. The main configuration uses zero bridge recomputation. | An independent answer-level channel-dependence diagnostic, not execution of a published audit's full code/protocol. It does not establish robustness, privacy protection, or resistance to poisoned latent states. The no-context control intentionally differs in length; the other corruption controls match evidence-cache length. |
| E4 — recomputation | Independently prefilled evidence is assembled once at 0%, 10%, 20%, or 100% requested recompute. At 100%, the prologue and selected documents receive full joint prefill. | Measures this boundary heuristic and its actual recompute counts, not a universal 15–20% recovery rule or a reproduction of CacheBlend/CacheClip. It is a single-assembly ablation rather than the complete multi-hop E1 trajectory. |
| E5 — precision | BF16, packed affine int8, and packed affine int4 versions of the assembled relay; actual array bytes include scale/bias overhead. | Measures answer sensitivity and packed cache payload, not quantized attention speed, native cache serialization throughput, or a deployed 10M-token cold store. |
| E6 — updates/conflicts | Synthetic explicit supersession metadata: all versions versus current-version filtering; equally authoritative conflicts retain both records. BEAM evaluates its update/contradiction categories using the retrieved excerpts. | Synthetic filtering assumes correct metadata; it does not train or test automatic write-time contradiction detection. BEAM lacks that supersession metadata, so its E6 case is category answering, not a duplicated “current” filter. |

E3 randomization matches each layer and KV head's mean and standard deviation over the token and head-dimension axes separately for K and V, then rounds to BF16; it does not preserve covariance or token structure. Audit-intervention flags survive concat/appends/precision changes and prohibit later recomputation from reconstructing the uncorrupted evidence from saved token IDs.

## Recorded real-weight numerical validation

Source: `runs/native-validation-relative/process.log`, produced by `scripts/validate_real_backend.py`. These are a small mechanics check on a 22-token, two-block sequence, not benchmark accuracy or a broad numerical equivalence guarantee.

| Check | Recorded measurement |
| --- | ---: |
| 100% bridge versus joint prefill: maximum key difference over all layers | 0.0 |
| 100% bridge versus joint prefill: maximum next-logit difference | 0.0 |
| Append versus joint prefill: same argmax next token | true |
| Append versus joint prefill: maximum next-logit difference | 0.15625 |
| Source layer-zero key snapshot changed after operations | 0.0 maximum absolute difference |
| Shifted versus joint layer-zero keys: normalized RMS error | 0.00027924845926463604 |
| Unshifted versus joint layer-zero keys: normalized RMS error | 0.08045480400323868 |
| Shifted versus joint layer-zero keys: maximum absolute error | 0.125 |
| Joint layer-zero key maximum absolute magnitude | 209.0 |
| Requested 20% bridge: actual recomputed tokens | 5 / 22 = 22.7272727% |
| MLX peak allocation during this validation | 16,638,666,880 bytes = 15.496 GiB |

Position correction reduced the relative key error about **288×** in this check. Post-RoPE BF16 composition adds rounding, so use the recorded scale-aware criterion: normalized RMS error below 0.01 and at least 10× lower than the unshifted control. The earlier absolute threshold of 0.1 failed and its log was retained. Do not claim append is bit-identical to joint prefill; only full recomputation was bit-identical here. Independent tiny-Qwen3 CPU tests additionally cover source immutability, unchanged unselected bridge positions, packed quantization, audit moments, and bounded decoding.

The validation guard finished successfully in 2.053 seconds and sampled peak process RSS of 13.194 GiB. Those are this short validation's measurements, not model-load benchmarks or the peak/latency of the complete experiment matrix. MLX allocation and sampled process RSS are different accounting measures.

## Verified KV payload and scale extrapolation

For Qwen3-8B, the cache has `36 × 8 × 128 × 2 = 73,728` K/V elements per token. BF16 uses two bytes per element. Quantization adds `73,728 / 64 × (2 + 2) = 4,608` bytes of scale/bias data per token.

| Cache format | Measured bytes/token | Fraction of BF16 | 1,000,000 tokens | 10,000,000 tokens |
| --- | ---: | ---: | ---: | ---: |
| BF16 | 147,456 | 100% | 147.456 GB / 137.329 GiB | 1,474.560 GB / 1,373.291 GiB |
| Packed int8, groups of 64 | 78,336 | 53.125% | 78.336 GB / 72.956 GiB | 783.360 GB / 729.561 GiB |
| Packed int4, groups of 64 | 41,472 | 28.125% | 41.472 GB / 38.624 GiB | 414.720 GB / 386.238 GiB |

GB is decimal (`10^9` bytes); GiB is binary (`2^30` bytes); token counts are decimal millions. These figures are **arithmetic extrapolations from measured native-array payload**, not allocations or disk stores created at those scales. They exclude original token IDs, metadata, Python objects, serialization headers, weights, allocator overhead, temporary concatenation buffers, and dequantized working copies.

The measured reductions are **1.882×** for int8 and **3.556×** for int4, not idealized 2×/4×. The original plan's roughly 37 GB for one million 4-bit tokens excludes the actual scale/bias overhead: this implementation needs 41.472 GB of packed arrays. Ten million require 414.720 GB. Even one million int4 tokens exceed the deliberately imposed 32 GiB MLX cap, before model weights. This does not imply the laptop has only 32 GiB; the experiment intentionally leaves substantial system headroom.

One 8,192-token BF16 cache is 1.125 GiB; its packed int8 and int4 payloads are 0.59765625 and 0.31640625 GiB. Attention still needs the BF16 form, and multiple source/assembled caches may coexist. “8 readers × 4,000 tokens” would be 4.718592 GB of BF16 cache payload, but the actual backend does not run a 32,000-token receiver context under its 8,192-token limit.

## Cost and product-status wording

- Warm latency encloses synchronized relay assembly, recomputation, quantization/dequantization, model forwards, and final decoding. Offline document prefill, model loading, donor preparation, ranking, and BEAM retrieval are recorded separately rather than silently included in that number.
- Per-example precomputation builds the prologue plus the union of documents selected across that example's configured cases. Thus its cold-ingestion measurement is explicitly a shared preparation scope, not a separate minimal cold cost for every arm/hop budget. Final host output tokens and internal decoded note tokens are separate counts.
- Public QA uses supplied distractor-context subsets. BEAM ranks chunks from three complete downloaded histories, then answers from bounded retrieved excerpts. It does not feed one million tokens into a single model context or precompute a complete million-token native KV store. Its local, condition-blind same-model rubric judge is exploratory and uncalibrated; free-form answer exact match is not the official BEAM metric.
- Native `MLXKVBlock` storage is separate from the legacy NumPy KV store. The native cache is not yet wired into that on-disk store/LRU or the MCP server. `server/server.py` still raises `NotImplementedError`; old agent pipelines explicitly reject real-model use. Do not describe either pipeline as a shippable fallback product.
- The proposed learned planner/verifier, embedding/reranker models, latent retrieval projection, compressor, automatic write-time update detection, LCGuard-style security evaluation, and BEAM-10M deployment remain outside these experiments. No general 100–200 ms latent-hop claim, 2-second end-to-end service claim, two-point parity conclusion, or adaptive-search kill decision follows from the mechanics validation.
- Deferred reproducibility issue: BEAM preparation embeds measured retrieval/index timings in normalized examples, so byte-identical regeneration is not currently expected even when evidence is unchanged. Preserve the evaluated prepared files and their recorded checksums; move volatile timings to sidecars or define a stable content digest in a later preparation revision, without rewriting the inputs of the frozen run.

## Source fingerprints for these notes

- `engine/backends_mlx.py`: `472828a6326efc7893f986f54c6df3c277ed04efcaf72c51673f695326d139e9`
- `eval/real_experiments.py`: `bdc7537cf94f05c25b55a32ec049f33343b7d83fe6474048380284dc6c5f453c`
- `scripts/validate_real_backend.py`: `6c16a3ce6d36c4cf54971fc8d9a4c41ea07a0cc35023b6d3825ca978a7f22fea`
- `runs/native-validation-relative/process.log`: `1605dbfdd500d681988b35e2552e32788b39c71d8be9492bddc08eedad12caa3`
