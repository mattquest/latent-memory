# Adaptive retrieval results

Status: **complete**

Cold timings include per-question tokenization, search, controller generation, cache construction and final generation. Model loading and the shared offline BM25 index are excluded and recorded in the manifest.

| Arm | Round cap | n | EM | F1 | Cold p50 / p95 (s) | Mean docs | Host / internal tokens |
| --- | --- | --- | --- | --- | --- | --- | --- |
| basic_rag | 1 | 6 | 0.0% | 0.0% | 0.39 / 0.62 | 6.0 | 3.0 / 0.0 |
| expanded_rag | 1 | 6 | 0.0% | 0.0% | 1.23 / 1.72 | 6.0 | 3.0 / 23.0 |
| incremental_kv_bf16 | 5 | 6 | 0.0% | 0.0% | 1.84 / 2.65 | 9.0 | 3.5 / 24.5 |
| iterative_text | 5 | 6 | 0.0% | 0.0% | 1.99 / 3.69 | 9.0 | 3.5 / 24.5 |
| relay_kv_bf16 | 5 | 6 | 0.0% | 0.0% | 2.31 / 2.95 | 7.5 | 2.0 / 22.3 |
| relay_kv_int8 | 5 | 6 | 0.0% | 0.0% | 2.33 / 2.97 | 7.5 | 2.0 / 22.3 |
| reranked_rag | 1 | 6 | 0.0% | 0.0% | 0.81 / 1.29 | 6.0 | 7.3 / 0.0 |

## Recovery where basic RAG failed exact match

This subset is defined after running basic RAG. It supplements the full-test table above.

| Arm | Round cap | Paired failures | Recovered | Recovery rate | Basic / enhanced cold p50 (s) |
| --- | --- | --- | --- | --- | --- |
| expanded_rag | 1 | 6 | 0 | 0.0% | 0.39 / 1.23 |
| incremental_kv_bf16 | 5 | 6 | 0 | 0.0% | 0.39 / 1.84 |
| iterative_text | 5 | 6 | 0 | 0.0% | 0.39 / 1.99 |
| relay_kv_bf16 | 5 | 6 | 0 | 0.0% | 0.39 / 2.31 |
| relay_kv_int8 | 5 | 6 | 0 | 0.0% | 0.39 / 2.33 |
| reranked_rag | 1 | 6 | 0 | 0.0% | 0.39 / 0.81 |

## Paired cache-method comparisons

Differences are target minus comparator on the same questions. Latency ratios are the median of per-question target/comparator ratios; below 1 means faster. JSON includes paired confidence intervals; constant differences have no estimated interval.

| Target | Comparator | Paired n | EM difference | F1 difference | Median cold latency ratio |
| --- | --- | --- | --- | --- | --- |
| incremental_kv_bf16 (5 rounds) | iterative_text (5 rounds) | 6 | +0.0 pp | +0.0 pp | 0.91 |
| incremental_kv_bf16 (5 rounds) | reranked_rag (1 rounds) | 6 | +0.0 pp | +0.0 pp | 2.29 |
| relay_kv_bf16 (5 rounds) | iterative_text (5 rounds) | 6 | +0.0 pp | +0.0 pp | 1.02 |
| relay_kv_bf16 (5 rounds) | reranked_rag (1 rounds) | 6 | +0.0 pp | +0.0 pp | 2.77 |
| relay_kv_bf16 (5 rounds) | incremental_kv_bf16 (5 rounds) | 6 | +0.0 pp | +0.0 pp | 1.19 |
| relay_kv_int8 (5 rounds) | iterative_text (5 rounds) | 6 | +0.0 pp | +0.0 pp | 1.03 |
| relay_kv_int8 (5 rounds) | reranked_rag (1 rounds) | 6 | +0.0 pp | +0.0 pp | 2.77 |
| relay_kv_int8 (5 rounds) | incremental_kv_bf16 (5 rounds) | 6 | +0.0 pp | +0.0 pp | 1.20 |

## Limits

- Global BM25 index and model loading are common offline setup; all per-question inference, retrieval and KV construction are charged.
- Iterative arms can retrieve more documents than the single-round baselines; improvements may come from additional evidence and model calls.
- All iterative controllers decode SEARCH/ANSWER actions. This is not a trained zero-text latent planner.
- Incremental KV is ordinary causal prefix reuse. Independent-document relay is separately labeled and may alter controller decisions.
- Primary-model prefill and all-model prefill totals are separate; all-model totals include every reranker input token when that optional arm is present.
- Basic-failure recovery is a posthoc conditional analysis; full-test results and paired denominators are reported alongside it.
- Single-model, greedy, bounded evaluation on a fixed public subset; no claim of official benchmark or general population performance.
