# MuSiQue data license

Trivedi et al. (2022), MuSiQue. Source: https://github.com/StonyBrookNLP/musique . License: CC-BY-4.0, https://creativecommons.org/licenses/by/4.0/ .

Changes: exact title/text deduplication, content-hash paragraph IDs, local structurally balanced question splits, prior-question exclusions, normalized JSONL, and separate scoring/provenance metadata. This is a local subset of the public answerable development split, not the publisher's hidden test set or full-Wikipedia benchmark.
