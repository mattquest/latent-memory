#!/usr/bin/env python3
"""Archive the owned supplemental evidence and curated public calibration facts."""
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from scripts.build_adaptive_report import archive
OUT = ROOT / 'reports/2026-09-11-large-controller'
manifest_path = OUT / 'artifact-manifest.json'
manifest = json.loads(manifest_path.read_text())
receipts = manifest['artifacts']
existing = {(item['source'], item['source_sha256']) for item in receipts}
sha = lambda raw: hashlib.sha256(raw).hexdigest()


def pack(path, raw=None, category='supplement'):
    path = Path(path).resolve()
    raw = path.read_bytes() if raw is None else raw
    key = (str(path), sha(raw))
    if key in existing:
        return
    relative = path.relative_to(ROOT)
    target = str(Path('artifacts') / category / (str(relative) + '.gz'))
    receipts[:] = [item for item in receipts if item['artifact'] != target]
    receipts.append(archive(OUT, Path(category) / (str(relative) + '.gz'), raw, path, compress=True))
    existing.add(key)


for name in ('scripts/project_controller_latency.py', 'tests/test_project_controller_latency.py',
             'runs/large-controller/export-validation-attempt1.json',
             'runs/large-controller/exporter-attempt1.py',
             'runs/large-controller/qualitative-audit.json',
             'runs/large-controller/qualitative-audit.md',
             'runs/large-controller/package_supplement.py'):
    pack(ROOT / name)

provider = ROOT / 'runs/large-controller/provider-latency'
published = OUT / 'provider-latency'
published.mkdir(exist_ok=True)
for name in ('workloads.json', 'projections.json', 'profiles.json', 'published-source-observations.json',
             'projection-audit.json', 'factual-source-summary-public-v1.md', 'provider-latency.md',
             'provider-latency.png', 'provider-pairs.csv', 'provider-summary.csv',
             'provider-render-receipt.json', 'render_provider_report.py',
             'lambda-qwen35-122b-extracted-benchmark-v1.json'):
    shutil.copyfile(provider / name, published / name)
    pack(provider / name)

# Publish provenance receipts only. Third-party HTML/docs remain local evidence.
receipt_dir = published / 'source-fetch-receipts'
receipt_dir.mkdir(exist_ok=True)
for source in sorted(provider.glob('*.receipt.json')):
    receipt = json.loads(source.read_text())
    if 'response_headers' in receipt:
        receipt['response_headers'] = {key: value for key, value in receipt['response_headers'].items()
            if key.lower() in {'date', 'content-type', 'content-length', 'etag', 'last-modified', 'age', 'cache-control'}}
        receipt['publication_note'] = 'Only content/timing/cache response headers retained; cookies and unrelated headers omitted.'
    (receipt_dir / source.name).write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
shutil.copyfile(provider / 'fetch-receipt.json', receipt_dir / 'fetch-receipt.json')

# Original older result ledgers and their executed sources already have a frozen
# public archive. Reuse those verified bytes without modifying the old report.
workloads = json.loads((provider / 'workloads.json').read_text())
needed = {entry['sha256'] for run in workloads['runs'] for entry in run['source_sha256']}
needed |= {entry['sha256'] for run in workloads['runs'] for entry in run['input_receipts']}
old = ROOT / 'reports/2026-09-11-controller-scaling'
old_receipts = json.loads((old / 'artifact-manifest.json').read_text())['artifacts']
for entry in old_receipts:
    if entry['source_sha256'] not in needed:
        continue
    packed = (old / entry['artifact']).read_bytes()
    assert len(packed) == entry['artifact_bytes'] and sha(packed) == entry['artifact_sha256']
    raw = gzip.decompress(packed) if entry['compression'] == 'gzip' else packed
    assert len(raw) == entry['source_bytes'] and sha(raw) == entry['source_sha256']
    pack(Path(entry['source']), raw, category='prior-controller')
assert needed <= {item['source_sha256'] for item in receipts}, 'Missing frozen workload source'
manifest_path.write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
print(json.dumps({'artifacts': len(receipts), 'supplemental_provider_files': len(list(published.rglob('*')))}))
